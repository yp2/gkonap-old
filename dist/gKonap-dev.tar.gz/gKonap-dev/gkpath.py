domyslny_katalog = "$HOME/projekty/gkonap/testy/trunk"
config_file = "$HOME/projekty/gkonap/testy/trunk/config/config_file"
icon = "/home/daniel/projekty/gkonap/trunk/gfx/icon.svg"
gladefile = "/home/daniel/projekty/gkonap/trunk/gkonap.glade"
wersja = 'dev'