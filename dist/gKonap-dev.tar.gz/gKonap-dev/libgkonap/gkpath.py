domyslny_katalog = "$HOME/git/gkonap-old/test/"
config_file = "$HOME/git/gkonap-old/test/config/config_file"
icon = "/home/daniel/git/gkonap-old/libgkonap/gfx/icon.svg"
wersja = 'dev'