#!/usr/bin/env python
#-*- coding: utf-8 -*-

'''
Created on 11-10-2012

@author: daniel
'''
